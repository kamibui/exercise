<form class="mb-4">

      <input 
      type="text" 
      name="city"
      class="form-control" 
      placeholder="Search City" 
      style="background-color: #E3ABD6; color: white; border: 1px solid #B080A4;"
      value="<?php echo $_GET["search"] ?>">
      <button class="btn btn-primary mt-2 w-15">Set Location</button>

      </form>

      <form action="" method="POST">